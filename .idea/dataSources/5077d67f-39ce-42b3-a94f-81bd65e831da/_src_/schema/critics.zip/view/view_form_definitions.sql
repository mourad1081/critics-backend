CREATE VIEW view_form_definitions AS
  SELECT
    `f`.`id`        AS `form_id`,
    `f`.`title`     AS `form_title`,
    `s`.`id`        AS `section_id`,
    `s`.`title`     AS `section_title`,
    `c`.`id`        AS `criterion_id`,
    `c`.`title`     AS `criterion_title`,
    `c`.`score_max` AS `criterion_score_max`
  FROM ((`critics`.`form_definitions` `f` LEFT JOIN `critics`.`section_definitions` `s`
      ON ((`s`.`form_id` = `f`.`id`))) LEFT JOIN `critics`.`criterion_definitions` `c`
      ON ((`c`.`section_id` = `s`.`id`)));
