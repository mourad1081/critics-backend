create view view_criteria as
select `critics`.`criteria`.`id`                     AS `id`,
       `critics`.`criteria`.`section_id`             AS `section_id`,
       `critics`.`criteria`.`score`                  AS `score`,
       `critics`.`criteria`.`note`                   AS `note`,
       `critics`.`criterion_definitions`.`title`     AS `title`,
       `critics`.`criterion_definitions`.`score_max` AS `score_max`,
       `critics`.`criterion_definitions`.`priority`  AS `priority`
from (`critics`.`criteria`
       left join `critics`.`criterion_definitions`
                 on ((`critics`.`criteria`.`criterion_definition_id` = `critics`.`criterion_definitions`.`id`)));

