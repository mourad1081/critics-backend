create view view_form_definitions as
select `f`.`id`        AS `form_id`,
       `f`.`title`     AS `form_title`,
       `s`.`id`        AS `section_id`,
       `s`.`title`     AS `section_title`,
       `c`.`id`        AS `criterion_id`,
       `c`.`title`     AS `criterion_title`,
       `c`.`score_max` AS `criterion_score_max`
from ((`critics`.`form_definitions` `f` left join `critics`.`section_definitions` `s` on ((`s`.`id` = `f`.`id`)))
       left join `critics`.`criterion_definitions` `c` on ((`c`.`id` = `s`.`id`)));

