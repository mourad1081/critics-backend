create view view_review_criteria as
select `c`.`id`          AS `criterion_id`,
       `c`.`score`       AS `criterion_score`,
       `c`.`note`        AS `criterion_note`,
       `cd`.`title`      AS `criterion_title`,
       `cd`.`score_max`  AS `criterion_score_max`,
       `cd`.`priority`   AS `criterion_priority`,
       `s`.`average`     AS `section_average`,
       `sd`.`title`      AS `section_title`,
       `sd`.`priority`   AS `section_priority`,
       `r`.`state`       AS `review_state`,
       `r`.`id`          AS `review_id`,
       `r`.`location_id` AS `review_location_id`,
       `r`.`created_at`  AS `review_created_at`,
       `fd`.`title`      AS `review_title`
from (((((`critics`.`criteria` `c` left join `critics`.`criterion_definitions` `cd` on ((`c`.`criterion_definition_id` = `cd`.`id`))) left join `critics`.`sections` `s` on ((`s`.`id` = `c`.`section_id`))) left join `critics`.`section_definitions` `sd` on ((`sd`.`id` = `cd`.`section_definition_id`))) left join `critics`.`reviews` `r` on ((`r`.`id` = `s`.`review_id`)))
       left join `critics`.`form_definitions` `fd` on ((`sd`.`form_definition_id` = `fd`.`id`)));

