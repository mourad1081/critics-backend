create view view_reviews as
select `critics`.`reviews`.`id`             AS `id`,
       `critics`.`reviews`.`user_id`        AS `user_id`,
       `critics`.`reviews`.`state`          AS `state`,
       `critics`.`reviews`.`location_id`    AS `location_id`,
       `critics`.`form_definitions`.`title` AS `title`,
       `critics`.`reviews`.`picture`        AS `picture`,
       `critics`.`reviews`.`created_at`     AS `created_at`
from (`critics`.`reviews`
       left join `critics`.`form_definitions`
                 on ((`critics`.`reviews`.`form_definition_id` = `critics`.`form_definitions`.`id`)));

