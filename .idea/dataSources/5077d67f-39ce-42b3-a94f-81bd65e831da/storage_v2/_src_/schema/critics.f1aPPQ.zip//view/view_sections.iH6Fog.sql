create view view_sections as
select `critics`.`sections`.`id`                  AS `id`,
       `critics`.`sections`.`average`             AS `average`,
       `critics`.`section_definitions`.`title`    AS `title`,
       `critics`.`section_definitions`.`priority` AS `priority`,
       `critics`.`sections`.`review_id`           AS `review_id`
from (`critics`.`sections`
       left join `critics`.`section_definitions`
                 on ((`critics`.`sections`.`section_definition_id` = `critics`.`section_definitions`.`id`)));

